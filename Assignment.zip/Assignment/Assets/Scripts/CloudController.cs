﻿/*
+------------------------------------------------------------+
| Source file name: CloudController.cs                         |
| Author’s name: Bahman Yaghoubi Vije                        |
| Last Modified by: Bahman Yaghoubi Vije                     |
| Date last Modified: October 26, 2016                        |
| Program description: Sky is the name of the background     |
|	of this game. It is moving from right to left. This      |
|	class controlles the direction, and movement of the Sky. |
| Revision History: N/A                                      |
+------------------------------------------------------------+
*/

using UnityEngine;
using System.Collections;

public class CloudController : MonoBehaviour {

	// *** Cloud is put on the scene to show the movement of the scene more clearly ***

	// a variable to control the speed of the cloud on the scene
	[SerializeField]
	private float speed;
	// initialize two variables holding the specifications of the cloud object
	private Transform _transform;
	private Vector2 _currentPosition;
	private const float _BORDER = 10f;
	private const float _HEIGHT = 4f;

	// Use this for initialization
	void Start () {
		_transform = transform;
		_currentPosition = _transform.position;
	}

	// Update is called once per frame
	void Update () {
		// change the position of the cloud based on speed 
		_currentPosition -= new Vector2 (speed, 0);
		_transform.position = _currentPosition;
		// check the sky position not go out of the game boundaries
		if (_currentPosition.x <= - _BORDER) {
			Reset ();
		}
	}
	// reset the position of the cloud object
	private void Reset(){
		// set the position in a way that user can see the sky continiously
		_currentPosition = new Vector2 (_BORDER, _HEIGHT);
		_transform.position = _currentPosition;
	}
}