﻿/*
+------------------------------------------------------------+
| Source file name: FoxController.cs                         |
| Author’s name: Bahman Yaghoubi Vije                        |
| Last Modified by: Bahman Yaghoubi Vije                     |
| Date last Modified: October 26, 2016                        |
| Program description: Fox is the main player Avatar. This   |
|	class controls the speed and direction of the fox.       |
| Revision History: N/A                                      |
+------------------------------------------------------------+
*/

using UnityEngine;
using System.Collections;

public class FoxController : MonoBehaviour {

	// a variable to control the speed of the fox on the scene
	[SerializeField]
	private float speed;
	// initialize two variables holding the specifications of the fox object
	private Transform _transform;
	private Vector2 _currentPosition;

	private const float VERTICAL_BORDER = 2.8f;
	private const float HORIZONTAL_BORDER = 10f;


	// Use this for initialization
	void Start () {
		_transform = transform;
		_currentPosition = _transform.position;
	}

	// FixedUpdate is called on a reliable timer, independent of the frame rate.
	void FixedUpdate () {
		// control the direction of the fox movement based on the user's input key
		if (Input.GetAxis ("Horizontal") != 0)
			_currentPosition += new Vector2 (speed * 10 * Mathf.Sign(Input.GetAxis ("Horizontal")), 0);
		else if (Input.GetAxis ("Vertical") != 0)
			_currentPosition += new Vector2 (0, speed * 10 * Mathf.Sign(Input.GetAxis ("Vertical")));

		_checkBounds();
		_transform.position = _currentPosition;
	}

	private void _checkBounds(){
		// check the position of the fox not to go out of the game scene boundaries
		if (_currentPosition.y < - VERTICAL_BORDER) {
			_currentPosition.y = - VERTICAL_BORDER;
		}
		if (_currentPosition.y > VERTICAL_BORDER) {
			_currentPosition.y = VERTICAL_BORDER;
		}

		if (_currentPosition.x < - HORIZONTAL_BORDER) {
			_currentPosition.x = - HORIZONTAL_BORDER;
		}
		if (_currentPosition.x > HORIZONTAL_BORDER) {
			_currentPosition.x = HORIZONTAL_BORDER;
		}
	}
}