﻿/*
+------------------------------------------------------------+
| Source file name: FoxCollider.cs                           |
| Author’s name: Bahman Yaghoubi Vije                        |
| Last Modified by: Bahman Yaghoubi Vije                     |
| Date last Modified: October 26, 2016                        |
| Program description: This class controls the actions on    |
|	the event of all collisions in the game. Collision       |
|	between the player and any game object should be managed |
|	difeerently based on the game's logic.                   |
| Revision History: N/A                                      |
+------------------------------------------------------------+
*/

using UnityEngine;
using System.Collections;

public class FoxCollider : MonoBehaviour {

	// *** Fox is the Avatar under the user's control. User can use the standard keys (WASD) 
	//	   as well as the arrow keys for player movement  ***

	public AudioSource[] sounds;	
	public AudioSource audioBirdCatch;
	public AudioSource audioHitBySword;
	public AudioSource audioHitByFlame;
	public static AudioSource audioDeath;	
	public static AudioSource audioWin;

	public static int pointUp = 10;
	public static int healthDown = 10;

	// Use this for initialization
	void Start () {
		// initialize all the sound objects
		sounds = GetComponents<AudioSource>();
		if(sounds[0]!=null)
			audioBirdCatch = sounds[0]; 	if(sounds[1]!=null)
			audioHitBySword = sounds[1];
		if(sounds[2]!=null)
			audioHitByFlame = sounds[2]; 
		if(sounds[3]!=null)
			audioDeath = sounds[3];
		if(sounds[4]!=null)
			audioWin = sounds[4];
	}
	// when trigger happens, update points and health regarding to the collieded object 	
	void OnTriggerEnter2D (Collider2D other)
	{
		// if the collided object is bird
		if (other.tag == "Bird") {
			Debug.Log ("Collision with Bird");
			// increase the points when the fox eats a bird
			Player.Instance.Points += pointUp;
			// play bird wings sound
			audioBirdCatch.Play ();
			// disapear the collided bird
			BirdController bc = other.GetComponent<BirdController> ();
			if (bc != null) {
				bc.Reset ();
			}
		// if the collided object is sword 
		} else if (other.tag == "Sword") {
			Debug.Log ("Collision with Sword");
			// decrease the health when the fox is hit by a sword
			Player.Instance.Health -= healthDown;
			// play snab sound effect 
			audioHitBySword.Play ();
			// disapear the collided sword 
			SwordController sc = other.GetComponent<SwordController> ();
			if (sc != null) {
				sc.Reset ();
			} 
		// if the collided object is flame
		} else if (other.tag == "Flame") {
			Debug.Log ("Collision with Flame");
			// decrease the health when the fox is hit by a sword
			Player.Instance.Health -= healthDown;
			// play snab sound effect
			audioHitByFlame.Play ();
			// disapear the collided flame
			FlameController bmc = other.GetComponent<FlameController> ();
			if (bmc != null) {
				bmc.Reset ();
			}
		}
	}
}
