﻿/*
+------------------------------------------------------------+
| Source file name: FlameController.cs                       |
| Author’s name: Bahman Yaghoubi Vije                        |
| Last Modified by: Bahman Yaghoubi Vije                     |
| Date last Modified: October 26, 2016                        |
| Program description: Flame is the BossMonster of this game |
| 	which shows up only if the player reaches 150 points.    |
|	Flames are 3 times faster than Swords, so make the game  |
|	harder for the player. This class controls the direction,|
|	speed and patern of the Flame game objects.				 |
| Revision History: N/A                                      |
+------------------------------------------------------------+
*/

using UnityEngine;
using System.Collections;

public class FlameController : MonoBehaviour {

	// *** Sword is the BossMonster our fox wants to avoid. If the fox be hit by the flame, it will loose health ***

	// a variable to control the speed of the flame on the scene
	[SerializeField]
	private Vector2 speed;
	// initialize two variables holding the specifications of the flame object
	private Transform _transform;
	private Vector2 _currentPosition;
	// an integer value which would be either 1 or -1. This acts as a sign to 
	// define the direction to which the flame object is going to move
	int direction = 1;

	// Use this for initialization
	void Start () {
		_transform = transform;
		_currentPosition = _transform.position;
	}

	// FixedUpdate is called on a reliable timer, independent of the frame rate.
	void FixedUpdate () {
		_currentPosition = _transform.position;
		Vector2 currSpeed = new Vector2 (speed.x * direction, speed.y );
		_currentPosition -= currSpeed;
		_transform.position = _currentPosition;
		// check the flame position not go out of the game boundaries
		if (_currentPosition.y <= -5.2f) {
			Reset ();
		}
	}
	// reset the position of the flame objects
	public void Reset(){
		// chenge the direction of the flame each time
		direction = -direction;
		_transform.localScale = new Vector2 (1, direction);
		_currentPosition = new Vector2 (direction * 5f, 5f);
		_transform.position = _currentPosition;
	}
}