﻿/*
+------------------------------------------------------------+
| Source file name: SwordController.cs                       |
| Author’s name: Bahman Yaghoubi Vije                        |
| Last Modified by: Bahman Yaghoubi Vije                     |
| Date last Modified: October 26, 2016                        |
| Program description: Sword is the Player's enemy in this   |
|	game. This class controls the direction, speed and       |
|	patern of the Sword game objects.	                     |
| Revision History: N/A                                      |
+------------------------------------------------------------+
*/

using UnityEngine;
using System.Collections;

public class SwordController : MonoBehaviour {

	// *** Sword is the enemy our fox wants to avoid. If the fox be hit by the sword, it will loose health ***

	// a variable to control the speed of the swords on the scene
	[SerializeField]
	private Vector2 speed;
	// initialize two variables holding the specifications of the sword object
	private Transform _transform;
	private Vector2 _currentPosition;

	// an integer value which would be either 1 or -1. This acts as a sign to 
	// define the direction to which the sword object is going to move
	int direction = 1;

	// Use this for initialization
	void Start () {
		_transform = transform;
		_currentPosition = _transform.position;
	}
	
	// FixedUpdate is called on a reliable timer, independent of the frame rate.
	void FixedUpdate () {
		// on each update, set the position accordingly
		_currentPosition = _transform.position;
		// randomly change the direction of sword's move each time
		Vector2 currSpeed = new Vector2 (speed.x * direction, speed.y );
		_currentPosition -= currSpeed;
		_transform.position = _currentPosition;
		// check the sword position not go out of the game boundaries
		if (_currentPosition.y <= -5.2f) {
			Reset ();
		}
	}
	// reset the position of the sword objects
	public void Reset(){
		// generate a random number which can be 1 or 2
		int sign = Random.Range (1, 3);

		float height = Random.Range (3, 6);
		// apply the -1 direction 1 or 2 times based on the random number generated
		// this way, the direction of the swords are completely unpredictable, and
		// makes the game more exciting
		for (int i = 0; i  < sign; i++)
			direction = -direction;
		_transform.localScale = new Vector2 (1, direction);
		// set a zone in which the swords are moving 
		_currentPosition = new Vector2 (direction * 10f, height);
		_transform.position = _currentPosition;

	}
}