﻿/*
+------------------------------------------------------------+
| Source file name: Player.cs                                |
| Author’s name: Bahman Yaghoubi Vije                        |
| Last Modified by: Bahman Yaghoubi Vije                     |
| Date last Modified: October 26, 2016                        |
| Program description: This singleton class guarantees that  |
|	there is one and only one player object at a time in the |
|	game. Data members of this class are encapsulated.       |
| Revision History: N/A                                      |
+------------------------------------------------------------+
*/

using UnityEngine;
using System.Collections;

public class Player {

	private Player (){}

	private static Player _instance = null;
	public HUDController hud = null;
	// variable to keep and update the value of the player's points
	private int _points = 0;
	// variable to keep and update the value of the player's health
	private int _health = 100;

	// make the Player instance accessible whithin the project
	public static Player Instance{
		// guarantee that there will be no more than one player at a time
		get{ 
			if (_instance == null) {
				_instance = new Player ();
			}
			return _instance;
		}
	}
		
	// make the points variable accessible whithin the project
	public int Points{
		get {
			return _points;
		}

		set{ 
			_points = value;
			hud.updatePoints ();
		}
	}

	// make the health variable accessible whithin the project
	public int Health{
		get {
			return _health;
		}

		set{ 
			_health = value;
			hud.updateHealth ();
		}
	}
}
