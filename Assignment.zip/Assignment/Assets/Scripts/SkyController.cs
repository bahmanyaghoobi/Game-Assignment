﻿/*
+------------------------------------------------------------+
| Source file name: SkyController.cs                         |
| Author’s name: Bahman Yaghoubi Vije                        |
| Last Modified by: Bahman Yaghoubi Vije                     |
| Date last Modified: October 26, 2016                        |
| Program description: Sky is the name of the background     |
|	of this game. It is moving from right to left. This      |
|	class controlles the direction, and movement of the Sky. |
| Revision History: N/A                                      |
+------------------------------------------------------------+
*/

using UnityEngine;
using System.Collections;

public class SkyController : MonoBehaviour {

	// *** Sky is the background of the scene. It moves horizontally while game is being played ***

	// a variable to control the speed of the sky 
	[SerializeField]
	private float speed;
	// initialize two variables holding the specifications of the sky
	private Transform _transform;
	private Vector2 _currentPosition;
	private const float _BORDER = 10f;
	private const float _HEIGHT = 0;

	// initialize the background sound object
	public AudioSource[] sounds;
	public static AudioSource background;

	// Use this for initialization
	void Start () {
		sounds = GetComponents<AudioSource>();
		if(sounds[0]!=null)
			background = sounds[0]; 
		_transform = transform;
		_currentPosition = _transform.position;
	}
	
	// Update is called once per frame
	void Update () {
		// change the position of the sky based on speed 
		_currentPosition -= new Vector2 (speed, _HEIGHT);
		_transform.position = _currentPosition;
		// check the sky position not go out of the game boundaries
		if (_currentPosition.x <= - _BORDER) {
			Reset ();
		}
	}
	// reset the position of the sky object
	private void Reset(){
		// set the position in a way that user can see the sky continiously
		_currentPosition = new Vector2 (_BORDER, _HEIGHT);
		_transform.position = _currentPosition;

	}
}

// sky: https://i.ytimg.com/vi/lIX2-UKKvZA/maxresdefault.jpg
// Fox: https://www.assetstore.unity3d.com/en/#!/content/59175
// Sword: https://www.assetstore.unity3d.com/en/#!/content/18270
// flame: https://www.assetstore.unity3d.com/en/#!/content/18270
// bird: https://www.assetstore.unity3d.com/en/#!/content/27774
// Sound: (bird, sword, flame): https://www.assetstore.unity3d.com/en/#!/content/62378
// Sound: (background): https://www.assetstore.unity3d.com/en/#!/content/60232
// Sound: (Win): https://www.assetstore.unity3d.com/en/#!/content/16644
// cloud: https://www.assetstore.unity3d.com/en/#!/content/58833




