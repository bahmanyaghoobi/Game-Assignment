﻿/*
+------------------------------------------------------------+
| Source file name: HUDController.cs                         |
| Author’s name: Bahman Yaghoubi Vije                        |
| Last Modified by: Bahman Yaghoubi Vije                     |
| Date last Modified: October 26, 2016                        |
| Program description: A class to control changes in the     |
| 	Heads Up Display part of the UI. Points and Health of    |
| 	the player is controlled in this class                   |
| Revision History: N/A                                      |
+------------------------------------------------------------+
*/

using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class HUDController : MonoBehaviour {

	// initialize three variables to keep the text value of the UI labels
	[SerializeField]
	Text pointsLabel = null;

	[SerializeField]
	Text healthLabel = null;

	[SerializeField]
	Text gameResultLabel = null;
	// initialize a variable to keep the UI Button (Restart)
	[SerializeField]
	Button restart = null;

	// BossMonster of the game 
	GameObject flame, fox, cloud; 
	GameObject[] birds, swords;

	// a boolean value to keep track of the fox, if it is resized or not
	// we do not want it to be resized more than once
	bool scaledDown = false;

	// a function which is going to be called each time the points are updated
	public void updatePoints(){

		// string value of the points label
		pointsLabel.text = "Points: " + Player.Instance.Points;

		// if user points is more than 250 the game shpuld desplay a message informing 
		// the user that he/she has won the game. It should also provide the restart button 
		if (Player.Instance.Points >= 250) {
			GameOver("You Won!");
			// play the win sound
			FoxCollider.audioWin.Play();
			// stop the background sound
			SkyController.background.Stop();
		// if points is still not 250, but it has exceeded 200, as a prize to the user, 
		// the fox gets smaller to be more flexible to avoid the swords. This happens only once
		// and it shouldn't resize the fox on each update
		} else if (Player.Instance.Points >= 200){
			// checks if resize has been done before
			if (scaledDown == false) {
				// reduce the size of the fox
				Vector3 temp = fox.transform.localScale;
				temp.x -= 1f;
				temp.y -= 1f;
				fox.transform.localScale = temp;
				// also increase the number of points being gained by eating each bird
				// and decrease the number of health being lost by being hit by the sword
				FoxCollider.pointUp = 20;
				FoxCollider.healthDown = 5;
				// change the boolean value to true, so from this point on, the code inside this if 
				// statement will not be proccessed anymore
				scaledDown = true;
			}
		// if points is still not 200, but it has exceeded 150, the bossmonster of the game apears
		// The bossmonster is just a new enemy which is moving 3 times faster than the current 
		//enemy (sword). The current enemy also remains at the scene
		} else if (Player.Instance.Points >= 150) {
		// If player has done very well on the game, the boss monster will show up
			flame.SetActive (true);
		} 
	}
	// update the health label, and finish the game if health is 0 or less
	public void updateHealth(){
		// string value of the health label
		healthLabel.text = "Health: " + Player.Instance.Health;
		// if the player has run out of health game over message should be placed on the screen
		// and the game should be halted
		if(Player.Instance.Health <= 0)
		{
			// play the death sound
			FoxCollider.audioDeath.Play();
			// stop the background sound
			SkyController.background.Stop();
			// call a function to finish the game
			GameOver("Game Over!");
		// if health is still more than 0, then literally do nothing
		} else gameResultLabel.text = "";
	}

	// Use this for initialization
	void Start () {
		restart.gameObject.SetActive (false);
		// get the only flame object in the scene
		flame = GameObject.FindGameObjectsWithTag ("Flame")[0];
		// get the only fox object in the scene
		fox = GameObject.FindGameObjectsWithTag ("Fox")[0];
		// get the only cloud object in the scene
		cloud = GameObject.FindGameObjectsWithTag ("Cloud")[0];
		// find all sword game objects
		swords = GameObject.FindGameObjectsWithTag ("Sword");
		// find all bird game objects
		birds = GameObject.FindGameObjectsWithTag ("Bird");
		// if time has been stopped in the previous game over, retain the usual timing
		Time.timeScale = 1;
		Player.Instance.hud = this;
		gameResultLabel.text = "";
		// on the start of the game do not show the restart button
		restart.gameObject.SetActive (false);
		// also do not show the flame object
		flame.SetActive (false);
	}

	// a function which is going to be called each time the health is updated
	void GameOver(string message){
		
		// set the label based on the game result (won or lost).
		gameResultLabel.text = message;
		// halt the game time
		Time.timeScale = 0;


		// show the restart button
		restart.gameObject.SetActive (true);
		// onClick listner for the newly activated restart button
		restart.onClick.AddListener(() => {
			// reset points and health of the player before restarting the game
			Player.Instance.Points = 0;
			Player.Instance.Health = 100;
			// reset the sclale to which points and health are going to be changed in the game
			FoxCollider.pointUp = 10;
			FoxCollider.healthDown = 10;
			// call a function to restart the current level (the only level we actually have)
			RestartCurrentScene();
		});
		// make all the birds deactive when the game is over	
		foreach(GameObject bird in birds)
			bird.SetActive (false);
		// make all the swords deactive when the game is over
		foreach(GameObject sword in swords)
			sword.SetActive (false);
		// make the health label deactive when the game is over
		healthLabel.gameObject.SetActive (false);
		// make the points label deactive when the game is over
		pointsLabel.gameObject.SetActive (false);
		// make the falme deactive when the game is over
		flame.SetActive (false);
		// make the cloud deactive when the game is over
		cloud.SetActive (false);
	}
	// a function to restart the current level
	public void RestartCurrentScene()
	{
		// gets the index of the current active scene
		int scene = SceneManager.GetActiveScene().buildIndex;
		// load the scene with the specific index 
		SceneManager.LoadScene(scene, LoadSceneMode.Single);
	}
}
