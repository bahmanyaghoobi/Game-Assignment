﻿/*
+------------------------------------------------------------+
| Source file name: BirdController.cs                        |
| Author’s name: Bahman Yaghoubi Vije                        |
| Last Modified by: Bahman Yaghoubi Vije                     |
| Date last Modified: October 26, 2016                        |
| Program description: This class controls the birds which   |
|	are randomly placed in the scene. Player would try to    |
|	collide with the birds in order to collect points.       |
| Revision History: N/A                                      |
+------------------------------------------------------------+
*/

using UnityEngine;
using System.Collections;

public class BirdController : MonoBehaviour {

	// *** Bird is something our fox wants to eat. If the fox eats the bird, it will gain points ***

	// a variable to control the speed of the birds on the scene
	[SerializeField]
	private float speed;
	// initialize two variables holding the specifications of the bird object
	private Transform _transform;
	private Vector2 _currentPosition;

	private float miny = -10f;
	private float maxy = 10f;


	// Use this for initialization
	void Start () {
		_transform = transform;
		_currentPosition = _transform.position;
	
	}
	
	// Update is called once per frame
	void Update () {
		// on each update, set the position accordingly
		_currentPosition = _transform.position;
		// change the vertical position based on the speed
		_currentPosition -= new Vector2 (0, speed);
		_transform.position = _currentPosition;
		// check the bird position not go out of the game boundaries
		if (_currentPosition.y <= -5f) {
			Reset ();
		}
	
	}
	// reset the position of the bird objects
	public void Reset(){
		// generate a random position for the bird
		float xpos = Random.Range (miny, maxy);
		float ypos = 5f;
		_currentPosition = new Vector2 (xpos, ypos);
		_transform.position = _currentPosition;
	}
}	