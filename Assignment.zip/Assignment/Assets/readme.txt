                                         Horror | Screamer image
										 
										 Fast Start :
										 
    1. import package.
	2. Screamer appeared to be placed at the scene and adjust their prefabs.
	3. In the settings, select Screamer sound (audio source), image and time lost through which Screamer.
	4. After all the settings, when a character enters the trigger Screamer will turn on.
	5. To put your picture on the Screamer enough to change it in the settings UI to adjust the sound and simply change it to Audio Source.